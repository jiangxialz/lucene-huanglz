package com.userinfo.myservlet;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.article.database.DBConnector;

public class MyServlet extends HttpServlet 
{
	// 数据库连接变量
    Connection con = null;
    Statement sm = null;
    /**
     * 初始化Servlet实例时调用该方法
     */
    public void init() throws ServletException {
        super.init();
        // 从web.xml中读取servlet的配置参数
        String dbURL = this.getServletConfig().getInitParameter("dbURL");
        String driver = this.getServletConfig().getInitParameter("driver");
        String username = this.getServletConfig().getInitParameter("username");
        String password = this.getServletConfig().getInitParameter("password");
        try {
            // 连接数据库
            con = DBConnector.getConnection(driver, dbURL, username, password);
            sm = con.createStatement();
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }
    
    /**
     * 处理doGet请求，当JSP表单中的method为get时，会调用该方法
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        this.doPost(request, response);
    }
    /**
     * 处理doPost请求，当JSP表单中的method为post时，会调用该方法
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
    	
    	UserInfoDao userinfoDao = null;
    	
    }
    
    /**
     * 销毁Servlet实例时，调用该方法
     */
    public void destroy() {
        super.destroy();
        try {
            // 关闭Statement
            if (sm != null){
                sm.close();
            }
        } catch (Exception e1){
        }
        try {
            // 关闭Connection
            if (con != null){
                con.close();
            }
        } catch (Exception e1){
        }
    }
    
    public String getServletInfo() {
        return "Query Database Servlet";
    }

	
}