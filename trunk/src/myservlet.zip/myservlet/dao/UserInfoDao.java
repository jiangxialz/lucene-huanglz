public interface UserInfoDao extends BaseDao<UserInfo> 
{  
	public boolean insertUser(UserInfo userInfo);  
	  
	public boolean updateUser(UserInfo userInfo);  
	  
	public boolean deleteUser(String uname);  
	  
	public ArrayList<UserInfo> getAllUsers();  
	  
	public UserInfo getUserByName(String uname);  
  
 }  