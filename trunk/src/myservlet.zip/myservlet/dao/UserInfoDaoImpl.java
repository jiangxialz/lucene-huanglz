public class UserInfoDaoImpl extends DaoSupport<UserInfo> implements UserInfoDao
{     
    @Override  
    public boolean deleteUser(String uname) {  
        // TODO Auto-generated method stub  
        String sql="delete from t_userinfo where uname=?";  
        Object[] obj={uname};         
        return this.update(sql, obj);  
    }  
  
    @Override  
    public ArrayList<UserInfo> getAllUsers() {  
        // TODO Auto-generated method stub  
        String sql="select * from t_userinfo ";  
        return this.query(sql, null);  
    }  
  
    @Override  
    public UserInfo getUserByName(String uname) {  
        // TODO Auto-generated method stub  
      String sql="select * from t_userinfo where uname=?";  
      Object[] obj=new Object[]{uname};     
      ArrayList<UserInfo> list=this.query(sql, obj);  
      UserInfo bean=null;  
      if (list.size()>0) bean=list.get(0);       
        return bean;  
    }  
  
    @Override  
    public boolean insertUser(UserInfo userInfo) {  
        // TODO Auto-generated method stub  
        String sql="insert into t_userinfo values(?,?)";  
        Object[] obj=new Object[]{userInfo.getUname(),userInfo.getUpwd()};  
        return this.update(sql, obj);  
    }  
  
    @Override  
    public boolean updateUser(UserInfo userInfo) {  
        // TODO Auto-generated method stub  
        String sql="update t_userInfo set upwd=? where uname=?";  
        Object[] obj=new Object[]{userInfo.getUpwd(),userInfo.getUname()};  
        return this.update(sql, obj);  
    }  
  
}  