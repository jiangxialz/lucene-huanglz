package myservlet.dao;

import java.util.ArrayList;

public interface BaseDao<T> 
{ //采用泛型类  
	public ArrayList<T> query(String sql,Object[] obj);  
	public boolean update(String sql,Object[] obj);  
}  