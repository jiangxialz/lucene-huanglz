import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DaoSupport<T> implements BaseDao<T> 
{  
    private Connection con;  
    private ResultSet rs;  
    private PreparedStatement pstmt;  
    private Class clazz = GenericUtils.getSuperGenericType(this.getClass()); //获得超类，参数化类型。  
  
    public ArrayList<T> query(String sql, Object[] obj) {  
        ArrayList<T> list = new ArrayList<T>();  
        con = DBUtil.getConnection();  
        try {  
            pstmt = con.prepareStatement(sql);  
            if (obj != null) {  
                for (int i = 0; i < obj.length; i++) {  
                    pstmt.setObject(i + 1, obj[i]);  
                }  
            }  
            rs = pstmt.executeQuery();  
  
            list = mapping(rs);  
        } catch (SQLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
  
        return list;  
    }  
  
    public ArrayList<T> mapping(ResultSet rs) {  
        ArrayList<T> list = new ArrayList<T>();  
        try {  
            while (rs.next()) {  
                Object obj = this.clazz.newInstance();  
  
                Field[] fields = this.clazz.getDeclaredFields();  
                for (int i = 0; i < fields.length; i++) {  
                    String fieldName = fields[i].getName();  
                    // setter  
                    String setMethodName = "set"  
                            + fieldName.substring(0, 1).toUpperCase()  
                            + fieldName.substring(1);  
                    // Method  
                    Method m = this.clazz.getDeclaredMethod(setMethodName,  
                            fields[i].getType());  
                    // 调用方法,防止类型不匹配，自写  
                    if (fields[i].getType().equals(int.class)) {  
                        m.invoke(obj, rs.getInt(fieldName));  
                    } else if (fields[i].getType().equals(Date.class)) {  
                        m.invoke(obj, rs.getDate(fieldName));  
                    } else {  
                        m.invoke(obj, rs.getObject(fieldName));  
                    }  
  
                }  
  
                list.add((T) obj);  
  
            }  
        } catch (Exception e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        }  
  
        return list;  
    }  
  
    public boolean update(String sql, Object[] obj) {  
        con = DBUtil.getConnection();  
        try {  
            pstmt = con.prepareStatement(sql);  
            if (obj != null) {  
                for (int i = 0; i < obj.length; i++) {  
                    pstmt.setObject(i + 1, obj[i]);  
                }  
            }  
  
            if (pstmt.executeUpdate() > 0)  
                return true;  
        } catch (SQLException e) {  
            // TODO Auto-generated catch block  
            e.printStackTrace();  
        } finally {  
            DBUtil.closeAll(con, pstmt, null);  
        }  
  
        return false;  
    }  
  
}  