package myservlet.dao;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

public class GenericUtils 
{  
	public static Class getSuperGenericType(Class clazz)
	{  
		//超类是参数化类型  
		Type type=clazz.getGenericSuperclass();  
		  
		//ParameterizedType 表示参数化类型，如 Collection<String>。   
		ParameterizedType paramType=(ParameterizedType)type;  
		  
		//返回表示此类型实际类型参数的 Type 对象的数组。   
		Type[] types=paramType.getActualTypeArguments();  
		return (Class)types[0];  
	}
}  